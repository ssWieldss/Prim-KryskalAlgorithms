#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;


int main()
{
	system("chcp 1251");
	int M, N; // �������, �����
	cin >> M >> N;
	vector<pair<int, pair<int, int>>> arr(N); // lenght, first, second
	vector<bool> edges(M);

	for (int i = 0; i < N; i++)
	{
		cin >> arr[i].first >> arr[i].second.first >> arr[i].second.second;
	}

	sort(arr.begin(), arr.end());
	int weight = 0;
	for (int i = 0; i < N; i++)
	{
		if (!edges[arr[i].second.first] || !edges[arr[i].second.second])
		{
			weight += arr[i].first;
			edges[arr[i].second.first] = true;
			edges[arr[i].second.second] = true;
			cout << "[" << arr[i].second.first << ";" << arr[i].second.second << "]";
		}
	}
	cout << endl;
	cout << "����������� ��� ������:";
	cout << weight << endl;

	return 0;
}
